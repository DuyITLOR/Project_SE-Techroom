import React from 'react'

const TeacherDashboard = () => {
  return (
    <div>TeacherDashboard</div>
  )
}

export default TeacherDashboard